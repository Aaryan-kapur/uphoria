let data ={
    "isac": 
        {
            "events": {
                "event-1": {
                    "name": "B-roll",
                    "content": "An open themed video making competition in which you’ll be not just restricted with time, but with the area which will be available and type of shots too. In this challenge, you’ll have to make the video in 7 hours only using B roll shots \n Team - 3-5 members \n Theme: Open Theme (will be declared at the start time for the competition \n Who Can Enter? Students who are registered in any program in an educational institute of India and have a valid Identity card can  participate in the event. \n How to Enter? The competition will require participants to mail their entries to isac.mediaclub@gmail.com with the subject “The ISAC B Roll Challenge” by date. \n General Instructions: The participants will be given an area as the competition begins in which they’ll have to make a video consisting of B roll type shots.Total time that will be given for shooting, editing and submitting the video will be 7 hours. The area for shooting the video will be communicated via e-mail and the videos should be submitted within the given time limit . Judging will be done on the same \n  Participation fees : Rs. 50 per member \nPoint of Contact \n  Bhavya Patunjal - 9971010672 \n   bhavya.patunjal@bennett.edu.in ) "
                },
                "event-2": {
                    "name": "Graphic Designing",
                    "content": "An open themed graphic designing competition in which you'll be restricted by the software tech and no use of internet \n Team – Individual \n Theme: Open Theme (will be declared at the start time for the competition \n Who Can Enter? Students who are registered in any program in an educationalinstitute of India and have a valid Identity card can participate in the event.\n How to Enter? The competition is during Uphoria and is open to all students present in Bennett University at that time. Digital images that are sent via mail or via messages on Facebook pages will not be accepted. \n  Event Guidelines: The participants will be given an area as the competition begins in which they’ll have to create their art piece.\n Rules: \n 1. It is on the spot designing competition. \n 2. Only individual entries will be accepted. \n 3. Only Adobe Photoshop, Illustrator, GIMP, Inkscape or CorelDRAW may be used. \n4. No use of the internet is allowed. \n Participation Fee : Rs. 50 per individual  \nPoint of Contact \n  Bhavya Patunjal - 9971010672 \n   bhavya.patunjal@bennett.edu.in"
                },

                "event-3": {
                    "name": "PhotoHunt",
                    "content": "A Photo Scavenger Hunt is an activity that involves groups finding interesting things and capturing them using a camera. A simple yet fun way to promote teamwork and bonding. \n Team - 3-5 members. \n Theme: Open Theme \n Who can Enter? Students who are registered in any program in an educational institute of India and have a valid Identity card can participate in the event. \n How to Enter? The competition will require participants to mail their entries to isac.mediaclub@gmail.com with the subject “The ISAC Photo hunt ” by date. \n Event Guidelines:Once the teams arrive and are ready with sheets and cameras, they  are ready to be sent out into the Campus. The time limit and  meeting place for debriefing would be declared. Groups have to  email the photos as they collect them, Groups must also stay  together at all times (no splitting up). When time is up, Each group  will present their photos along with their sheet. Each group earns  one point for each challenge successfully photographed and extra  bonus points for creativity or effort.  \n Rules \n  1. The Video must be shot in a resolution of 720p or greater. It can  be shot on any device, a DSLR or a phone or a Point-and-Shoot  camera. \n 2. The Video may or may not have credits at the end. The name of  the film should be made visible at the start of the video. \n 3. Maximum duration of the film can be 90 seconds, including  credits and film title and everything in between.\n  4. The film should have been made in the 7 hours of  commencement of the competition.\n  5. The team should be present in the fest for the video to be taken  into consideration. \n Participation Fee : Rs. 50 \n Point of Contact: \n Bhavya Patunjal - 9971010672  \n bhavya.patunjal@bennett.edu.in"
                }
            }
        },
        
            "robotics": 
                {
                    "events": {
                        "event-1": {
                            "name": "Gaming Workshop",
                            "content": "A workshop in which an instructor would teach the attendees how to build a game from scratch, prizes would be given to students who finish first. \n Participation Fee - Rs. 100 \n Point of Contact:   \n  Alok Mishra - 9958524967     \n alok.mishra@bennett.edu.in"
                        },
                        "event-2": {
                            "name": "Backyard Science ",
                            "content": "Build the strongest and tallest   structure using straws and hot glue. \n  Participation Fee - Rs. 50  \n Point of Contact:   \n  Alok Mishra - 9958524967     \n alok.mishra@bennett.edu.in"
                        },
        
                        "event-3": {
                            "name": "Coding Competition ",
                            "content": "A competition based on participants    web development skills.   \n Participation Fee - Rs. 50 \n Point of Contact:   \n  Alok Mishra - 9958524967     \n alok.mishra@bennett.edu.in"
        
                        },
                        "event-4": {
                            "name": "Code-Jack",
                            "content": "Code-Jack will be a casino themed coding        contest in which people can visit the casino        machines which contain coding problems to        solve in a limited time.     \n   In collaboration with ACM.    \n     Participation Fee - Rs. 50 \n Point of Contact:   \n  Alok Mishra - 9958524967     \n alok.mishra@bennett.edu.in"
        
                        }
                    }
                },
                
                    "ansh": 
                        {
                            "events": {
                                "event-1": {
                                    "name": "Aakrosh : A reflection of our society",
                                    "content": "Street Play Competition \n Use of derogatory terms are strictly prohibited. Their usage may lead to immediate disqualification. \n Participants should bring their own props  with them \n  Participants should carry their college ID cards with them \n Any form of electronic music is not allowed The play can be in either English, or Hindi. Traces from regional    language are allowed.  \n  The play can be stopped at any point of time by the judges if they    find it unfit to continue \n Script should not contain any kind of content that is either      offensive, or hurts the sentiments of any social group.     \n The decision of the Judges and Organizing Committee will be final      and binding.     \n Date : 9Th February     \n Time Limit : 20+2 minutes    \n Team of minimum 10 persons     \n Participation Fee : Rs. 50 per person \n Point of Contact:   \n   Shivam Yadav - 9650356885  \n    shivam.yadav@bennett.edu.in"
                                },
                                "event-2": {
                                    "name": "coming soon",
                                    "content": "coming soon"
                                },
                
                                "event-3": {
                                    "name": "coming soon",
                                    "content": "coming soon"
                
                                }
                            }
                        },
                        
                            "pulse": 
                                {
                                    "events": {
                                        "event-1": {
                                            "name": "Snapathon",
                                            "content": "A spontaneous fun event for the social media addicted generation.  Lets use our creativity and the weird snapchat filters to win some  exciting prizes. \n Team: 4 per team \n Description:         The competition will comprise of three rounds         \n Teams will be eliminated after the three rounds, giving us just one         winner         \n All tasks will be performed through snapchat          First round will have basic tasks for example kiss the dog, largest         group selfie etc and the teams will be judged on the basis of the         creativity        \n  Second round will be a group task, all the members of the team will         have to perform the tasks assigned        \n Third round will have one major task that will check the creativity,         spontaneity and involvement of the public in general       \n   The winning team will be decided on the total of the points gained         through the three rounds. \nParticipation Fee : Rs. 100 per team     \n   Point of Contact:      \n  Aditi Tyagi - 9651008392   \n     at7143@bennett.edu.in  "
                                        },
                                        "event-2": {
                                            "name": "coming soon",
                                            "content": "coming soon"
                                        },
                        
                                        "event-3": {
                                            "name": "coming soon",
                                            "content": "coming soon"
                        
                                        }
                                    }
                                },
                                
                                    "cerebrum": 
                                        {
                                            "events": {
                                                "event-1": {
                                                    "name": "POP QUIZ",
                                                    "content": "Do you know your Dank Memes? Ever faced an existential crisis   after binging the hottest TV show to its end? Do you make it a point   to keep yourself upto date with the latest trends?   Cerebrum is here with your fix. It's time to get Schwifty with   Qriosity, Pop Quiz. We promise you it won't just be a quiz, it will be   an experience   Guidelines:     \n   1) The Pop quiz consists of two rounds:    \n    a) Preliminaries: Written round where teams would be given a fixed        set of questions. Top six teams will make it to the Finale. Winners        will be decided on the basis of total number of questions answered        by each team. In case of tie(s), winners will be decided on the basis        of priority of the questions answered correctly by each team and a        special tie breaker round.    \n    b) Finale: Winning six teams will go through five different rounds in        the finale. Top two teams with the highest scores at the end of the        fifth round will be declared as the winners. In case of tie(s), special        tie breaker round will be organized to find two distinct winners.       \n Participation Fee : Rs. 150 per team    \n   Team : 3 Members  \n Point of Contact: \n    Rishabh Mishra - 8860323649 \n    rishabh.mishra@bennett.edu.in"
                                                },
                                                "event-2": {
                                                    "name": "LMFAO",
                                                    "content": "Over the past few years, the growth of stand-up comedy in India   has been phenomenal. From having a highly limited comedy scene   that was mostly restrained to reality shows on television that   employed the same stream of half-hearted jokes over and over   again, India now has an evolving comedy scene that comprises an   entire industry. Taking a cue, Cerebrum is providing students a   platform to display their funny side, by participating in its   no-holds-barred stand-up competition, LMFAO and an opportunity   to win exciting prizes and recognition for themselves. \n Guidelines:   \n      1) People interested can participate as individuals.    \n     2) LMFAO consists of two rounds:     \n    a) Qualifier Round: Each individual has to submit a 6 minute video         (at max.) of their bit with their names and their institute’s name at         cerebrumbennett@gmail.com before         1200 hrs, 7th February.         \n i) Participants can use virtual (animation, graphics, etc.) and          physical props in their bits.       \n  b) Finale Round: Shortlisted participants will perform before an         audience on 8th February.      \n    i) Participants can use physical props in their bits.       \n   ii) Each individual will be given 10 minutes for their bit. In the Final Round, winners will be decided based on audience polling (40% weightage) and judge’s score (60% weightage). \n Participation Fee : Rs. 50 per individual \n Point of Contact:   \n Rishabh Mishra - 8860323649  \n  rishabh.mishra@bennett.edu.in"
                                                    
                                                },
                                
                                                "event-3": {
                                                    "name": "Spin the Yarn",
                                                    "content": "As the famous saying goes - “Juice is temporary. Sauce is       forever.” We at Uphoria fest egg you to get your creative juices flowing       and show us if you have the sauce to create something extremely       creative at our creative writing festival “Spin the Yarn”.       \n Guidelines:      \n 1) Spin the Yarn consists of two rounds:      \n a) Preliminary Round: Participants will have to submit a written       piece which starts with, “It’s just like pictures in a book. It isn’t       real” at cerebrumbennett@gmail.com before 1200 hrs, 7th February with       their names and their institute’s names.       In case of multiple entries, only the first entry would be considered.      \n Word Limit – 500 words      \n b) Final Round: Select participants will be competing onsite and       would be required to write a creative piece on a topic that will be       provided to them on the spot.    \n   Word Limit – 300 words    \n   Participation Fee : Rs. 30 per individual     \n Point of Contact:   \n Rishabh Mishra - 8860323649  \n  rishabh.mishra@bennett.edu.in"
                                                },

                                                "event-4": {
                                                    "name": "War of Words",
                                                    "content": "It is better to debate a question without settling it than to                  settle a question without debating it.     \n             Guidelines:     \n             1) War of Words consists of two rounds:     \n             a) Preliminary Round: Participants will be competing in a turncoat                  style debate.    \n              i) Topics will be given on the spot and each participant shall be given                  four minutes to prepare.     \n             ii) The participants will have to argue both sides of the topic                  themselves, that is, they would be speaking both for and against the                  motion.     \n             iii) The participants will have to speak for the motion of the house                  for two minutes, and then switch their stance to against the motion                  and speak for another two minutes.     \n             iv) The remaining time from one segment can’t carry over to the                  other.      \n            b) Final Round: Shortlisted participants from the Preliminary Round                  will be competing in Oxford-Style debate (1v1). Rules will be                  explained on the spot.       \n           Participation Fee : Rs. 50 per individual \n Point of Contact:   \n Rishabh Mishra - 8860323649  \n  rishabh.mishra@bennett.edu.in"

                                                
                                            }
                                        },
                                        
                                            "nomads": 
                                                {
                                                    "events": {
                                                        "event-1": {
                                                            "name": "Funk from Junk",
                                                            "content": "Funk from junk is basically an activity that tests your    creativity.It shows how you can change the perception of an    environment in seconds and react to it immediately.    Guidelines: Junk parts to be be collected from the campus    in stipulated time limit. The collected parts need to be    assembled into a product. The product will be pitched    infront of judges.    \n Winner gets a sponsored trip.   \n  Participation Fee : Rs. 200 per person \n Point of Contact:  \n    Shourya Vir Singh - 9736510542  \n    shouryavir.singh@bennett.edu.in"
                                                        },
                                                        "event-2": {
                                                            "name": "Zorbing",
                                                            "content": "Run down a slope, walk or stumble. Have loads of fun in this   recreational activity which involves giant inflatable balls   called Zorbs. \n  Participation Fee : Rs. 80 per person  \n Point of Contact:  \n    Shourya Vir Singh - 9736510542  \n    shouryavir.singh@bennett.edu.in"
                                                        },
                                        
                                                        "event-3": {
                                                            "name": "coming soon",
                                                            "content": "coming soon"
                                        
                                                        }
                                                    }
                                                },
                                                
                                                    "advaita": 
                                                        {
                                                            "events": {
                                                                "event-1": {
                                                                    "name": "Solo Singing (Eastern + Western)",
                                                                    "content": "Selections to be done based on a       3-minute video. The video must        contain only vocals without any       backing track or accompanying       instruments     \n  Finale Round      \n 1. Each participant will be given a       time of 3+2 minutes (Performance       + Setup)      \n 2. A maximum of 2 accompanying instrumentalist is allowed      \n 3. Participants must arrange for their own instrument(s)     \n  4. Use of synthesizer tracks and pre-recorded tracks is strictly       prohibited. Any participant found violating this rule will be liable to       immediate disqualification.     \n  5. Classical is not allowed.     \n  6. No limitation on genre.     \n  Send your videos at music.club.bennett@gmail.com      \n Participation Fee : Rs. 150      \n Point of Contact : Shivam Shukla \n 8962471371      \n Shivam.shukla@bennett.edu.in       "
                                                                },
                                                                "event-2": {
                                                                    "name": "Battle of Bands",
                                                                    "content": "Prelims       \n  1. video auditions (5 to 6mins)       \n  2. video should be sent via email       \n  Finals (In Campus)    \n     1. 30minutes (including sound check)     \n    2. No instruments will be provided by the college (Except drum set)      \n   3. No restrictions in genre      \n   4. Original Compositions are allowed (Lyrics of the same must be         submitted beforehand via email)      \n   5. No pre-recorded music is allowed (including looping, backing         track)      \n   6. Minimum 3 participants      \n   7. Maximum 10 participants     \n    Send your videos at music.club.bennett@gmail.com     \n    Participation Fee : Rs. 300 per person \n Point of Contact : Shivam Shukla \n 8962471371      \n Shivam.shukla@bennett.edu.in       "
                                                                },
                                                
                                                                "event-3": {
                                                                    "name": "Group Song Competition",
                                                                    "content": "Create a musical ambience with your group of talented musicians    and acappella artists.   \n Rules and Regulation  \n  1. No restrictions on language.  \n  2. Self-compositions are allowed (lyrics to be emailed)  \n  3. A maximum of 7 members are allowed (at least 1 vocalist)  \n  4. Except Acappella, maximum 3 vocalists are allowed  \n  5. Performances must strictly be acoustic.  \n  6. Acapella performances are also allowed.  \n  7. Time limit 10 minutes including sound check and setup  \n  8. Only acoustic/semi acoustic instruments including Keyboard are    allowed (Drums not included)    \n   9. No pre-recorded tracks are allowed    \n   10. Participants must bring their own instruments    \n   Prelims will be done based on videos submitted (not exceeding 5    minutes)    \n  Participation Fee : Rs. 50 per person \n Point of Contact : Shivam Shukla \n 8962471371      \n Shivam.shukla@bennett.edu.in       "
                                                
                                                                }
                                                            }
                                                        },
                                                        
                                                            "spic macay": 
                                                                {
                                                                    "events": {
                                                                        "event-1": {
                                                                            "name": "Group Dance ",
                                                                            
                                                                            "content": "Folk and classical/         semi-classical/         Indian         contemporary         dance –     \n    The above         mentioned dances         are allowed.       \n  Maximum number         of participants is 20         and minimum is 6.     \n    Registration fees (if         required) will be 50         per person. \n Prize money -    \n   First position – 20000    \n   Second position – 13000     \n  Venue – Big stage "
                                                                        },
                                                                        "event-2": {
                                                                            "name": "Solo and Duet Dance ",
                                                                            "content": "Classical and Semi-classical – Classical and semi-classical dance    forms are allowed. Registration fees for sooo is 30 per person and  for duet is 50 per pair.   \n Prize money –   \n First position – 10000  \n  Second position – 7000 "
                                                                        },
                                                        
                                                                        "event-3": {
                                                                            "name": "coming soon",
                                                                            "content": "coming soon"
                                                        
                                                                        }
                                                                    }
                                                                },
                                                                
                                                                    "alexis": 
                                                                        {
                                                                            "events": {
                                                                                "event-1": {
                                                                                    "name": "Mock CID 3.0 ",
                                                                                    
                                                                                    "content": "This is an exercise which tests both the physical       strength and the mental health of participants. A       team should have 5 members precisely.    \n   This contains 2 rounds     \n  1) Preliminary Qualifying round (Saturday)   \n    2)Final round (Sunday)    \n   The Preliminary round is a modified version of a relay race. All the       teams will be segmented into smaller groups. Each group will go       through the round and whosoever completes the round fastest will       qualify for the final round.    \n   Selected ones will be further moving to round-two in which they       have to solve a Murder Mystery. Teams who will complete in round       2 in the shortest time will be winning the MOCK-CID.     \n  Registration fee - Rs. 100"
                                                                                },
                                                                                "event-2": {
                                                                                    "name": "Solo and Duet Dance ",
                                                                                    "content": "Classical and Semi-classical – Classical and semi-classical dance    forms are allowed. Registration fees for sooo is 30 per person and  for duet is 50 per pair.   \n Prize money –   \n First position – 10000  \n  Second position – 7000 "
                                                                                },
                                                                
                                                                                "event-3": {
                                                                                    "name" : "Group Dance - Frolic Fight",
                                                                                    "content" : "1. Time Limit for the song will minimum 4 minutes    and maximum 6 minutes.   \n 2. Each group can have minimum 5 and maximum 8 members.   \n  3. Choice of the song is open for participants.   \n  4. Any obscene/offensive song or music is not allowed.   \n   5. Participants can bring their songs in a pen-drive. Please carry an extra    pen drive as a back-up, if technical error arises.    \n   6. Please submit your pen-drive at least half an hour before the event    starts.    \n  7. Usage of props are allowed and groups are requested to carry their    own props. Please handle your props with care we are not responsible    for any mishappening.    \n   Judging Criteria:    The dance performance will be judged on the following criteria    \n  Creativity    \n  Costume    \n  Stage presence    \n  Transactions    \n  Formations    \n  Participation Fee - Rs. 100 per person"
                                                                
                                                                                }
                                                                            }
                                                                        },
                                                                        
                                                                            "verve": 
                                                                                {
                                                                                    "events": {
                                                                                        "event-1": {
                                                                                            "name" : "Group Dance - Frolic Fight",
                                                                                            "content" : "1. Time Limit for the song will minimum 4 minutes    and maximum 6 minutes.   \n 2. Each group can have minimum 5 and maximum 8 members.   \n  3. Choice of the song is open for participants.   \n  4. Any obscene/offensive song or music is not allowed.   \n   5. Participants can bring their songs in a pen-drive. Please carry an extra    pen drive as a back-up, if technical error arises.    \n   6. Please submit your pen-drive at least half an hour before the event    starts.    \n  7. Usage of props are allowed and groups are requested to carry their    own props. Please handle your props with care we are not responsible    for any mishappening.    \n   Judging Criteria:    The dance performance will be judged on the following criteria    \n  Creativity    \n  Costume    \n  Stage presence    \n  Transactions    \n  Formations    \n  Participation Fee - Rs. 100 per person"
                                                                        
                                                                                        },
                                                                                        "event-2": {
                                                                                            "name": " Solo dance competition - Jump & Jive",
                                                                                            "content": "Time limit is 2-3 minutes, negative points for exceeding the time limit.       The participants are requested to bring their own music in pendrives.       No extra time shall be given for installing pendrives. It should be done       prior to the event.     \n  Participants should get their own props. All props must be specified to       the event coordinator.       Lightening of matchsticks, candles or any derogatory acts are strictly       not allowed on stage       Choice of the song is open to the participants.       There is no specific theme.    \n   Judging Criteria:       The dance performance will be judged on the following criteria     \n  Costumes     \n Props used     \n   Expressions     \n  Choreography     \n Coordination/ synchronization     \n  Interpretation of the idea / Originality of the idea     \n  Participation Fee - Rs. 50 per person"
                                                                                        },
                                                                        
                                                                                        "event-3": {
                                                                                            "name" : "coming soon",
                                                                                            "content" : "coming soon"
                                                                        
                                                                                        }
                                                                                    }
                                                                                },
                                                                                
                                                                                    "silhouette": 
                                                                                        {
                                                                                            "events": {
                                                                                                "event-1": {
                                                                                                    "name" : "Book Cover",
                                                                                                    "content" : "Put your creativity into designing a book cover with the theme pop culture . Now it's time to judge a book by it's cover. \n  Participation Fee : Rs. 50"
                                                                                
                                                                                                },
                                                                                                "event-2": {
                                                                                                    "name": "Glass Paining",
                                                                                                    "content": "Creative enough to paint a glass with the theme pop culture Then let's do this.   \n      Participation Fee : Rs. 50    \n     *There are no pre-requisites           \n   Point of Contact:     \n    Ritvik Raj Singh \n 8800411002       \n  ritvik.singh@bennett.edu.in"
                                                                                                },
                                                                                
                                                                                                "event-3": {
                                                                                                    "name" : "coming soon",
                                                                                                    "content" : "coming soon"
                                                                                
                                                                                                }
                                                                                            }
                                                                                        },
                                                                                        
                                                                                            "karobaar": 
                                                                                                {
                                                                                                    "events": {
                                                                                                        "event-1": {
                                                                                                            "name" : "The Big Sell round-1 ",
                                                                                                            "content" : "Round 1 - Crossword         All teams will assemble at once place and begin their treasure hunt to look for few letters         which at the end will make a word, being the name of a country.         Teams will find a letter at each milestone, and at the back of the letter is clue for finding         another letter. Clues will be geographic locations and member of Karobaar will give the         second letter and clue and so on.           \n   The first 6 teams to figure the name of the company after finding all the letters will move         onto the second round.     \n    Time needed - 3 hours (10:30 am to 1:30 pm) "
                                                                                        
                                                                                                        },
                                                                                                        "event-2" : {
                                                                                                            "name": "The Big Sell round-2",
                                                                                                            "content": "Round 2 - Paristhiti       The teams will has to represent the company whose name they found in the first round.       The qualified 6 teams will be divided into 2 pools. Each pool will be given a situation. The       top 3 solutions qualify for the the last and final round.  \n     Time needed - 1. 5 hours ( 3:30 pm to 5 pm) "
                                                                                                        },
                                                                                        
                                                                                                        "event-3": {
                                                                                                            "name" : "The Big Sell round-3",
                                                                                                            "content" : "Round 3 - Enterprise    The 3 teams qualified in the previous round will be given a product given without any logo    and branding. Each team will have to come up with a logo, tagline and marketing strategy    for the given product.   \n Time needed - 2 hour (2:30 pm - 4:30 pm) \n Participants :       \n    Maximum teams: 20       \n    Members per team 4       \n   Guidelines -       \n   1. Each team should be of minimum 3 and maximum 5 students.       \n   2. All team members should be undergraduate students from any course and year.       \n   3. All teams have to assemble in given location at the beginning and end of Round 1.       \n   4. Failure to follow the time limits will result in disqualification.       \n   5. Each team has to assign one team leader who will be in contact with the member of           Karobaar for all details.           \n   6. Participating teams will be decided on first come first serve basis.           \n   7. Teams can register on spot, 30 minutes before Round 1 begins.           \n   Registration amount :           \n   Rs. 200 per team " 
                                                                                        
                                                                                                        }
                                                                                                    }
                                                                                                },
        }
}

let squares = document.getElementsByClassName('square')

function callEvent(element,club){

    let event1 = document.getElementById('event-1')
    let event2 = document.getElementById('event-2')
    let event3 = document.getElementById('event-3')
    event1.children[0].innerHTML = (data[club]['events']['event-1']['name'])
    event2.children[0].innerHTML = (data[club]['events']['event-2']['name'])
    event3.children[0].innerHTML=(data[club]['events']['event-3']['name'])
    element.children[0].children[1].children[0].innerHTML = (data[club]['events']['event-1']['content'])
    
    let events = element.children[1].children[0].children
    for (let i = 0; i < events.length; i++) {
        const newElement = events[i];
        newElement.addEventListener('click',()=>{
            if(newElement.classList.contains('event-1')){
                element.children[0].children[1].children[0].innerHTML = (data[club]['events']['event-1']['content'])
            }
            if (newElement.classList.contains('event-2')) {
                element.children[0].children[1].children[0].innerHTML = (data[club]['events']['event-2']['content'])
            } 
            if (newElement.classList.contains('event-3')) {
                element.children[0].children[1].children[0].innerHTML = (data[club]['events']['event-3']['content'])
            }
        })      
    }
}

function hideAll(){
    let backs = document.getElementsByClassName('hiddenjs')
    for (let index = 0; index < backs.length; index++) {
        const element = backs[index];
        element.style.visibility = 'hidden';
    }
}

function showdiv(club){
    let hiddens = document.getElementsByClassName('hiddenjs')
    for (let index = 0; index < hiddens.length; index++) {
        const element = hiddens[index];
            document.getElementById('squares').style.position = 'absolute'
            element.style.visibility = 'visible';
            callEvent(element,club)
    }
}

function expand(element){
    if(element.classList.contains('isac')){
        showdiv('isac')
    }
}

for (let index = 0; index < squares.length; index++) {
    const element = squares[index];
    element.addEventListener('click',()=>{
        expand(element)
    })   
}